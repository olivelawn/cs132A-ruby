class Photo < ActiveRecord::Base
  belongs_to :album
end
